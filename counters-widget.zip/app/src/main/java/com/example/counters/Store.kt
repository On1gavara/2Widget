package com.example.counters

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/*
 * Store.kt — «склад» данных. Здесь описано, ЧТО мы храним и КАК это
 * кладётся в память телефона и достаётся обратно.
 */

/** Одна запись истории: когда, на сколько изменили и какое стало число. */
data class Entry(val time: Long, val delta: Int, val value: Int)

/**
 * Один счётчик.
 * `data class` — удобный тип Kotlin: сам умеет сравниваться и копироваться.
 * `var` — поле можно менять, `val` — только читать.
 */
data class Counter(
    var name: String,
    var color: Int,
    var step: Int,
    var value: Int,
    var log: MutableList<Entry>
)

/** `object` — это одиночка: один экземпляр на всё приложение, создавать через Store() не нужно. */
object Store {
    private const val PREFS = "counters"   // имя файла настроек на телефоне
    private const val MAX_LOG = 100        // храним не больше 100 записей истории

    /** Палитра цветов. 0xFF... — это ARGB: первые две цифры (FF) — непрозрачность. */
    val COLORS = intArrayOf(
        0xFFFF6B4A.toInt(), // красно-оранжевый
        0xFF4DA3FF.toInt(), // голубой
        0xFF3DDC84.toInt(), // зелёный
        0xFFFFC145.toInt(), // жёлтый
        0xFFB48CFF.toInt()  // фиолетовый
    )

    /** Значения по умолчанию, пока ты ничего не настроил. */
    private fun defaultCounter(index: Int) = Counter(
        name = if (index == 0) "Вода" else "Отжимания",
        color = COLORS[if (index == 0) 1 else 0],
        step = if (index == 0) 1 else 5,
        value = 0,
        log = mutableListOf()
    )

    /** Достаёт счётчик номер index (0 или 1) из памяти телефона. */
    fun load(context: Context, index: Int): Counter {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val text = prefs.getString("c$index", null) ?: return defaultCounter(index)
        // try/catch: если данные вдруг повреждены, не падаем, а берём значения по умолчанию
        return try {
            fromJson(JSONObject(text))
        } catch (e: Exception) {
            defaultCounter(index)
        }
    }

    /** Сохраняет счётчик. commit() пишет сразу и надёжно (нам важно, чтобы нажатие не потерялось). */
    fun save(context: Context, index: Int, counter: Counter) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (counter.log.size > MAX_LOG) {
            counter.log = counter.log.take(MAX_LOG).toMutableList()
        }
        prefs.edit().putString("c$index", toJson(counter).toString()).commit()
    }

    // ---------- Превращение в JSON и обратно ----------
    // Память телефона хранит только простые значения, поэтому сложный объект
    // превращаем в текст (JSON) при сохранении и разбираем обратно при загрузке.

    private fun toJson(c: Counter): JSONObject {
        val log = JSONArray()
        for (e in c.log) {
            log.put(JSONObject().put("t", e.time).put("d", e.delta).put("v", e.value))
        }
        return JSONObject()
            .put("name", c.name)
            .put("color", c.color)
            .put("step", c.step)
            .put("value", c.value)
            .put("log", log)
    }

    private fun fromJson(o: JSONObject): Counter {
        val logJson = o.optJSONArray("log") ?: JSONArray()
        val log = mutableListOf<Entry>()
        for (i in 0 until logJson.length()) {
            val e = logJson.getJSONObject(i)
            log.add(Entry(e.getLong("t"), e.getInt("d"), e.getInt("v")))
        }
        return Counter(
            name = o.getString("name"),
            color = o.getInt("color"),
            step = o.getInt("step"),
            value = o.getInt("value"),
            log = log
        )
    }
}
