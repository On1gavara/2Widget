package com.example.counters

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/*
 * CounterWidget.kt — сам виджет.
 *
 * Как это работает:
 *  1. Виджет рисуется не нами, а лаунчером (рабочим столом). Мы лишь передаём ему
 *     «рецепт» картинки — объект RemoteViews.
 *  2. Кнопкам + и − мы вешаем PendingIntent — «отложенное сообщение».
 *     Когда нажимаешь кнопку, система отправляет это сообщение обратно в onReceive().
 *  3. В onReceive() мы меняем число, сохраняем в Store и перерисовываем виджет.
 */
class CounterWidget : AppWidgetProvider() {

    /** Система вызывает это, когда виджет только добавили на экран или пора его обновить. */
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Виджетов на экране может быть несколько, обновляем каждый
        for (id in appWidgetIds) {
            appWidgetManager.updateAppWidget(id, buildViews(context))
        }
    }

    /** Сюда прилетают все сообщения, в том числе наши нажатия на + и −. */
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent) // стандартные сообщения системы обработает родитель

        if (intent.action == ACTION_CHANGE) {
            val index = intent.getIntExtra(EXTRA_INDEX, 0) // какой счётчик: 0 или 1
            val sign = intent.getIntExtra(EXTRA_SIGN, 1)   // +1 или -1

            val counter = Store.load(context, index)
            val delta = sign * counter.step                // на сколько меняем
            counter.value += delta
            // add(0, ...) кладёт запись в НАЧАЛО списка, чтобы новые были сверху
            counter.log.add(0, Entry(System.currentTimeMillis(), delta, counter.value))
            Store.save(context, index, counter)

            refreshAll(context) // перерисовываем виджет с новым числом
        }
    }

    /** companion object — «статическая» часть класса: константы и функции, доступные без создания объекта. */
    companion object {
        const val ACTION_CHANGE = "com.example.counters.CHANGE"
        const val EXTRA_INDEX = "index"
        const val EXTRA_SIGN = "sign"

        /** Перерисовать все виджеты на экране. Вызываем из виджета и из MainActivity. */
        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, CounterWidget::class.java))
            for (id in ids) {
                manager.updateAppWidget(id, buildViews(context))
            }
        }

        /** Собирает «рецепт» картинки виджета из layout-файла и текущих данных. */
        private fun buildViews(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_counters)
            // Одна и та же функция заполняет обе колонки, различаются только номера и id элементов
            bind(context, views, 0, R.id.name0, R.id.value0, R.id.minus0, R.id.plus0)
            bind(context, views, 1, R.id.name1, R.id.value1, R.id.minus1, R.id.plus1)
            return views
        }

        /** Заполняет одну колонку виджета данными счётчика с номером index. */
        private fun bind(
            context: Context,
            views: RemoteViews,
            index: Int,
            nameId: Int,
            valueId: Int,
            minusId: Int,
            plusId: Int
        ) {
            val c = Store.load(context, index)

            views.setTextViewText(nameId, c.name)
            views.setTextViewText(valueId, c.value.toString())
            views.setTextColor(valueId, c.color) // число красится в выбранный цвет
            views.setTextViewText(minusId, "−${c.step}") // − — настоящий минус «−»
            views.setTextViewText(plusId, "+${c.step}")

            // Вешаем действия на нажатия
            views.setOnClickPendingIntent(minusId, changeIntent(context, index, -1))
            views.setOnClickPendingIntent(plusId, changeIntent(context, index, +1))
            // Нажатие на название открывает настройки
            views.setOnClickPendingIntent(nameId, openAppIntent(context, index))
        }

        /** Создаёт «отложенное сообщение» для нашего же виджета: «измени счётчик index на sign шагов». */
        private fun changeIntent(context: Context, index: Int, sign: Int): PendingIntent {
            val intent = Intent(context, CounterWidget::class.java).apply {
                action = ACTION_CHANGE
                putExtra(EXTRA_INDEX, index)
                putExtra(EXTRA_SIGN, sign)
            }
            // requestCode должен быть уникальным для каждой кнопки (0..3),
            // иначе система решит, что это одно и то же сообщение, и кнопки перепутаются
            val requestCode = index * 2 + if (sign > 0) 1 else 0
            return PendingIntent.getBroadcast(
                context,
                requestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Сообщение «открой приложение». */
        private fun openAppIntent(context: Context, index: Int): PendingIntent {
            val intent = Intent(context, MainActivity::class.java)
            return PendingIntent.getActivity(
                context,
                100 + index,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
    }
}
