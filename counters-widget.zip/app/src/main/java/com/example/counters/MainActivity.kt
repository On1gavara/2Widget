package com.example.counters

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/*
 * MainActivity.kt — экран приложения: настройки двух счётчиков и история.
 * Activity — это один экран Android. Всё, что меняется здесь, сохраняется в Store,
 * а потом виджет читает те же данные.
 */
class MainActivity : Activity() {

    // Список функций «обнови историю». Нужен, чтобы при возврате на экран
    // (например, после нажатий на виджете) история показала свежие данные.
    private val updaters = mutableListOf<() -> Unit>()

    /** onCreate — вызывается один раз, когда экран создаётся. */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // подключаем layout-файл

        val container = findViewById<LinearLayout>(R.id.container)
        for (i in 0..1) {
            // inflate превращает XML-шаблон section_counter в живой объект View
            val section = layoutInflater.inflate(R.layout.section_counter, container, false)
            container.addView(section)
            setupSection(section, i)
        }
    }

    /** onResume — вызывается каждый раз, когда экран снова становится видимым. */
    override fun onResume() {
        super.onResume()
        updaters.forEach { it() }
    }

    /** Настраивает одну секцию: заполняет поля и вешает обработчики на кнопки. */
    private fun setupSection(section: View, index: Int) {
        // findViewById ищет элемент по id внутри секции
        val title = section.findViewById<TextView>(R.id.sectionTitle)
        val nameField = section.findViewById<EditText>(R.id.nameField)
        val stepField = section.findViewById<EditText>(R.id.stepField)
        val swatchRow = section.findViewById<LinearLayout>(R.id.swatchRow)
        val saveButton = section.findViewById<Button>(R.id.saveButton)
        val resetButton = section.findViewById<Button>(R.id.resetButton)
        val valueLabel = section.findViewById<TextView>(R.id.valueLabel)
        val logText = section.findViewById<TextView>(R.id.logText)

        val counter = Store.load(this, index)
        title.text = "Счётчик ${index + 1}"
        nameField.setText(counter.name)
        stepField.setText(counter.step.toString())

        // ---------- Выбор цвета ----------
        var chosenColor = counter.color        // var — потому что значение будет меняться
        val swatches = mutableListOf<View>()

        // Перекрашивает кружки: у выбранного появляется серая обводка
        fun paintSwatches() {
            swatches.forEachIndexed { k, view ->
                view.background = circle(Store.COLORS[k], Store.COLORS[k] == chosenColor)
            }
        }

        for (color in Store.COLORS) {
            val swatch = View(this)
            val params = LinearLayout.LayoutParams(dp(40), dp(40))
            params.marginEnd = dp(10)
            swatch.layoutParams = params
            swatch.setOnClickListener {        // что делать при нажатии на кружок
                chosenColor = color
                paintSwatches()
            }
            swatchRow.addView(swatch)
            swatches.add(swatch)
        }
        paintSwatches()

        // ---------- История ----------
        val timeFormat = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())

        // Читает данные из Store и выводит текущее число и последние 30 записей
        fun showLog() {
            val c = Store.load(this, index)
            valueLabel.text = "Сейчас: ${c.value}"
            logText.text = if (c.log.isEmpty()) {
                "История пока пуста."
            } else {
                c.log.take(30).joinToString("\n") { e ->
                    val sign = if (e.delta > 0) "+" else "−"
                    "${timeFormat.format(Date(e.time))}   $sign${abs(e.delta)}   → ${e.value}"
                }
            }
        }
        showLog()
        updaters.add { showLog() }

        // ---------- Кнопка «Сохранить» ----------
        saveButton.setOnClickListener {
            val c = Store.load(this, index)
            // trim() убирает пробелы по краям, ifEmpty подставляет запасное название
            c.name = nameField.text.toString().trim().ifEmpty { "Счётчик ${index + 1}" }
            // toIntOrNull вернёт null, если введён не номер; ?: 1 — «а если null, то 1»
            c.step = stepField.text.toString().toIntOrNull()?.coerceIn(1, 9999) ?: 1
            c.color = chosenColor
            Store.save(this, index, c)
            stepField.setText(c.step.toString())
            CounterWidget.refreshAll(this)      // говорим виджету перерисоваться
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }

        // ---------- Кнопка «Сбросить в 0» ----------
        resetButton.setOnClickListener {
            val c = Store.load(this, index)
            c.value = 0
            c.log.clear()
            Store.save(this, index, c)
            CounterWidget.refreshAll(this)
            showLog()
        }
    }

    /** Рисует круглый кружок нужного цвета; selected=true добавляет обводку. */
    private fun circle(color: Int, selected: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(color)
            if (selected) setStroke(dp(4), Color.GRAY)
        }
    }

    /** Переводит dp в пиксели (на разных экранах плотность разная). */
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
